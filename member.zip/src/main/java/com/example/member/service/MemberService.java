package com.example.member.service;

import com.example.member.entity.Member;
import com.example.member.mapper.MemberMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class MemberService {

    @Autowired
    private MemberMapper memberMapper;

    /** 전체 회원 조회 */
    public List<Member>  findAll(){
        // code 입력
      log.info("MemberService 호출...........");
      return memberMapper.findAll();
    }
}
